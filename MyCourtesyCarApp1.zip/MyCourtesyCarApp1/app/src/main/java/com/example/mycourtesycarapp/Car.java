package com.example.mycourtesycarapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Car extends AppCompatActivity {
    ImageView ford,kia,mit,toyota,nissan,mazda;

    Dialog myDialog;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car);
        BottomNavigationView bottomNavigationView=findViewById(R.id.menu);
        bottomNavigationView.setOnNavigationItemSelectedListener(navListner);

        myDialog = new Dialog(this);


        ford = findViewById(R.id.img_ford);

        kia = findViewById(R.id.img_kia);
        mit = findViewById(R.id.img_mit);
        toyota = findViewById(R.id.img_toyota);
        nissan=  findViewById(R.id.img_nissan);
        mazda = findViewById(R.id.img_mazda);




    }

    public void ShowPopup(View v) {
        TextView txtclose;


        myDialog.setContentView(R.layout.mitsubishipop);
        txtclose = (TextView) myDialog.findViewById(R.id.txtclose);
        txtclose.setText("X");

        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.show();
    }


    public void ShowPopup1(View v) {
        TextView txtclose;


        myDialog.setContentView(R.layout.mazdapop);
        txtclose = (TextView) myDialog.findViewById(R.id.txtclose);
        txtclose.setText("X");

        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.show();
    }


    public void ShowPopup2(View v) {
        TextView txtclose;


        myDialog.setContentView(R.layout.nissanpop);
        txtclose = (TextView) myDialog.findViewById(R.id.txtclose);
        txtclose.setText("X");

        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.show();
    }


    public void ShowPopup3(View v) {
        TextView txtclose;


        myDialog.setContentView(R.layout.fordpop);
        txtclose = (TextView) myDialog.findViewById(R.id.txtclose);
        txtclose.setText("X");

        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.show();
    }


    public void ShowPopup4(View v) {
        TextView txtclose;


        myDialog.setContentView(R.layout.kiapop);
        txtclose = (TextView) myDialog.findViewById(R.id.txtclose);
        txtclose.setText("X");

        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.show();
    }


    public void ShowPopup5(View v) {
        TextView txtclose;


        myDialog.setContentView(R.layout.toyotapop);
        txtclose = (TextView) myDialog.findViewById(R.id.txtclose);
        txtclose.setText("X");

        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.show();
    }



    private  BottomNavigationView.OnNavigationItemSelectedListener navListner = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            int id= menuItem.getItemId();

            if (id == R.id.home)
            {

                Intent  Home = new Intent(Car.this,Home_Page.class);
                startActivity(Home);
                finish();
            }
            else if (id == R.id.car)
            {
                Intent  CAR = new Intent(Car.this,Car.class);
                startActivity(CAR);
                finish();
            }
            else if (id == R.id.Profie)
            {
                Intent  Profile = new Intent(Car.this,Profile.class);
                startActivity(Profile);
                finish();
            }
            return false;
        }

    };



}
