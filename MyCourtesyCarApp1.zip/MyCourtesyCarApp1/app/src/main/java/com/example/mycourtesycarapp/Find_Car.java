package com.example.mycourtesycarapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.DialogFragment;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;

import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.media.Image;
import android.media.ImageReader;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class Find_Car extends AppCompatActivity implements TimePickerDialog.OnTimeSetListener {


    public static final String TAG = "Find_CarActitvity";
    EditText Pickup, Dropoff;
    EditText mDate, mDate1;
    Button Print;
    ImageView imageView;
    TextView mMName,mMYear;

    int i=0;


    DatePickerDialog.OnDateSetListener mDatePicker, mDateDropoff;
    TextView locationtext;
    Double latitude = 0.0;
    Double longitude = 0.0;
    Geocoder geocoder;
    // List<Address> addresses ;

    Location gps_loc = null, network_loc = null, final_loc = null;
    Spinner mcar;
    String name[] = {"Mazda    ", "Mitsubishi    ", "Nissan    ", "Ford    ", "Kia    ", "Toyota    "};
    ArrayAdapter<String> adapter;
    String record = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find__car);



        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, name);
        BottomNavigationView bottomNavigationView = findViewById(R.id.menu);
        bottomNavigationView.setOnNavigationItemSelectedListener(navListner);


        Pickup = findViewById(R.id.PUDT);
        Dropoff = findViewById(R.id.DODT);
        mDate = findViewById(R.id.PUDD);
        mDate1 = findViewById(R.id.DODD);
        mcar = findViewById(R.id.findcar);
        imageView = findViewById(R.id.display);
        mMName=findViewById(R.id.name);
        mMYear=findViewById(R.id.manu);



        Print = findViewById(R.id.Search);

        Print.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {






                String Data = mDate.getText().toString();
                String Data1 = mDate1.getText().toString();
                String Time = Pickup.getText().toString();
                String Time1 = Dropoff.getText().toString();
                String Name = mMName.getText().toString();
                String Year = mMYear.getText().toString();


                Intent IO = new Intent(Find_Car.this, Confirm_Request.class);
                IO.putExtra("Data", Data);
                IO.putExtra("Data1", Data1);
                IO.putExtra("Time", Time);
                IO.putExtra("Dropoff", Time1);
                IO.putExtra("Name", Name);
                IO.putExtra("Year", Year);
                IO.putExtra("carValues",i);
                startActivity(IO);

            }




        });

        locationtext = (TextView) findViewById(R.id.location);
        geocoder = new Geocoder(this, Locale.getDefault());


        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_NETWORK_STATE) != PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(this, "not granted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Granted", Toast.LENGTH_SHORT).show();
        }

        try {
            gps_loc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            network_loc = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (gps_loc != null) {
            final_loc = gps_loc;
            latitude = final_loc.getLatitude();
            longitude = final_loc.getLongitude();

        } else if (network_loc != null) {
            final_loc = network_loc;
            latitude = final_loc.getLatitude();
            longitude = final_loc.getLongitude();

        } else {
            latitude = 0.0;
            longitude = 0.0;
        }


        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address>
                    addresses = geocoder.getFromLocation(latitude, longitude, 1);
            if (addresses != null && addresses.size() > 0) {
                String address = addresses.get(0).getAddressLine(0);
                String area = addresses.get(0).getLocality();
                String city = addresses.get(0).getAdminArea();
                String postalcode = addresses.get(0).getPostalCode();
                String fulladress = address + ", " + area + ", " + city + ", " + postalcode;
                locationtext.setText(fulladress);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


        mDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar Cal = Calendar.getInstance();
                int Year = Cal.get(Calendar.YEAR);
                int Month = Cal.get(Calendar.MONTH);
                int Day = Cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog Dialog = new DatePickerDialog(Find_Car.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth, mDatePicker, Year, Month, Day);
                Dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                Dialog.show();
            }
        });
        mDate1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar Cal = Calendar.getInstance();
                int Year = Cal.get(Calendar.YEAR);
                int Month = Cal.get(Calendar.MONTH);
                int Day = Cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog Dialog1 = new DatePickerDialog(Find_Car.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth, mDateDropoff, Year, Month, Day);
                Dialog1.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                Dialog1.show();
            }
        });
        mDatePicker = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG, "onDateSet: dd/mm/yyy: " + day + "/" + month + "/" + year);

                String date = day + "/" + month + "/" + year;
                mDate.setText(date);
            }
        };
        mDateDropoff = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG, "onDateSet: dd/mm/yyy: " + day + "/" + month + "/" + year);

                String date1 = day + "/" + month + "/" + year;
                mDate1.setText(date1);
            }
        };

        Pickup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment timePicker = new Timepicker();
                timePicker.show(getSupportFragmentManager(), "Pickup Time");
            }
        });
        Dropoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment timePicker1 = new Timepicker();
                timePicker1.show(getSupportFragmentManager(), "Drop off");
            }
        });
        mcar.setAdapter(adapter);
        mcar.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        record = "Mazda";
                        if(position==0){
                            imageView.setImageResource(R.drawable.mazda);
                            mMName.setText("Mazda 6");
                            mMYear.setText("2002");
                            i=1;


                        }
                        break;

                    case 1:
                        record = "Mitsubishi";
                        if(position == 1){
                            imageView.setImageResource(R.drawable.mitsubishi1);
                            mMName.setText("Mitsubishi Outlander");
                            mMYear.setText("2001");
                            i=2;
                        }
                        break;

                    case 2:
                        record = "Nissan";
                        if(position == 2){
                            imageView.setImageResource(R.drawable.nissan_gtr);
                            mMName.setText("Nissan GTR(R35)");
                            mMYear.setText("2007");
                            i=3;
                        }
                        break;
                    case 3:
                        record = "Ford";
                        if(position == 3){
                            imageView.setImageResource(R.drawable.ranger);
                            mMName.setText("Ford Ranger");
                            mMYear.setText("2012");
                            i=4;
                        }
                        break;
                    case 4:
                        record = "Kia";
                        if(position == 4){
                            imageView.setImageResource(R.drawable.seltos);
                            mMName.setText("Kia Seltos");
                            mMYear.setText("2019");
                            i=5;
                        }
                        break;
                    case 5:
                        record = "Toyota";
                        if(position == 5){
                            imageView.setImageResource(R.drawable.corolla);
                            mMName.setText("Toyota Corolla");
                            mMYear.setText("2004");
                            i=6;
                        }
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



    }


    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

        EditText Pickup = (EditText) findViewById(R.id.PUDT);
        Pickup.setText(hourOfDay + ": " + minute);



    }

    public void Search(View view) {
        startActivity(new Intent(getApplicationContext(), Confirm_Request.class));
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListner = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            int id = menuItem.getItemId();

            if (id == R.id.home) {

                Intent Home = new Intent(Find_Car.this, Home_Page.class);
                startActivity(Home);
                finish();
            } else if (id == R.id.car) {
                Intent CAR = new Intent(Find_Car.this, Car.class);
                startActivity(CAR);
                finish();
            } else if (id == R.id.Profie) {
                Intent Profile = new Intent(Find_Car.this, Profile.class);
                startActivity(Profile);
                finish();
            }
            return false;
        }

    };


}
