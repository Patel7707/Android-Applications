package com.example.mycourtesycarapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Registration extends AppCompatActivity {
    public static final String TAG = "TAG";

    EditText mFirstName,mLastName,mEmail,mPassword,mPhone;
    Button mRegisterBtn;
    FirebaseAuth fAuth;
    FirebaseFirestore mStore;
    String Userid;
    Dialog mDialog;
    ProgressBar progressBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        mFirstName=findViewById(R.id.FirstName);
        mLastName=findViewById(R.id.LastName);
        mEmail=findViewById(R.id.Email);
        mPassword=findViewById(R.id.Password);
        mPhone=findViewById(R.id.Phone);
        mRegisterBtn=findViewById(R.id.Register);


        mDialog=new Dialog(this);

        mStore= FirebaseFirestore.getInstance();
        fAuth=FirebaseAuth.getInstance();
        progressBar=findViewById(R.id.progressbar);

        if(fAuth.getCurrentUser() != null){
            startActivity(new Intent(getApplicationContext(),MainActivity.class));
            finish();
        }
        mRegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String Email=mEmail.getText().toString().trim();
                String password=mPassword.getText().toString().trim();
                final String FirstName= mFirstName.getText().toString().trim();
                final String LastName= mLastName.getText().toString().trim();
                final String Phone= mPhone.getText().toString().trim();


                if(TextUtils.isEmpty(Email)){
                    mEmail.setError("Email is Required");
                    return;
                }
                if(TextUtils.isEmpty(password)){
                    mPassword.setError("Password is Required");
                    return;
                }

                if(password.length() < 6){
                    mPassword.setError("Password Must be 6 Characters Long");
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);




                fAuth.createUserWithEmailAndPassword(Email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(Registration.this, "User Created & Stored", Toast.LENGTH_SHORT).show();
                            Userid=fAuth.getCurrentUser().getUid();
                            DocumentReference documentReference= mStore.collection("User").document(Userid);
                            Map<String,Object> user= new HashMap<>();
                            user.put("First Name",FirstName);
                            user.put("Last Name",LastName);
                            user.put("Email",Email);
                            user.put("Phone",Phone);


                            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d(TAG,"onSuccess: User Profile is Created For" + Userid);
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d(TAG,"onFailed:" +e.toString());
                                }
                            });
                            startActivity(new Intent(getApplicationContext(),Login.class));
                        }else{
                            Toast.makeText(Registration.this, "Error  !"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });
            }
        });



    }
    public void Showup(View view){
        TextView Close;
        mDialog.setContentView(R.layout.custompopup);
        Close=mDialog.findViewById(R.id.Close);
        Close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        mDialog.show();
    }
}
