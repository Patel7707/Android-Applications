package com.example.mycourtesycarapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.mikhaellopez.circularimageview.CircularImageView;

public class Profile extends AppCompatActivity {

    TextView mFirstName,mLastName,mEmail,mPhone;
    FirebaseAuth mAuth;
    FirebaseFirestore mStore;
    String UserID;
    Button cp, up;
    CircularImageView img;
    StorageReference mstorage;

    public Uri imguri;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        mFirstName=findViewById(R.id.FirstName1);
        mLastName=findViewById(R.id.LastName1);
        mEmail=findViewById(R.id.Email1);
        mPhone=findViewById(R.id.Phone1);
//

        mAuth=FirebaseAuth.getInstance();
        mStore=FirebaseFirestore.getInstance();


        UserID=mAuth.getCurrentUser().getUid();
        DocumentReference documentReference=mStore.collection("User").document(UserID);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@javax.annotation.Nullable DocumentSnapshot documentSnapshot, @javax.annotation.Nullable FirebaseFirestoreException e) {
                mFirstName.setText(documentSnapshot.getString("First Name"));
                mLastName.setText(documentSnapshot.getString("Last Name"));
                mEmail.setText(documentSnapshot.getString("Email"));
                mPhone.setText(documentSnapshot.getString("Phone"));


            }
        });

        mstorage= FirebaseStorage.getInstance().getReference("Images");


        BottomNavigationView bottomNavigationView = findViewById(R.id.menu);
        bottomNavigationView.setOnNavigationItemSelectedListener(navListner);



        cp = findViewById(R.id.choose);
        up = findViewById(R.id.Upload);

        img = findViewById(R.id.profile);

        cp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Filechoose();
            }
        });

        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fileuploader();
            }
        });


    }


    private String getExtension(Uri uri) {
        ContentResolver cr = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(cr.getType(uri));


    }


    private void Fileuploader() {
        StorageReference ref = mstorage.child(System.currentTimeMillis() + "." + getExtension(imguri));
        ref.putFile(imguri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        // Get a URL to the uploaded content
                        //Uri downloadUrl = taskSnapshot.getDownloadUrl();

                        Toast.makeText(Profile.this, "IMAGE UPLOADED SUCCESSFULLY", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Handle unsuccessful uploads
                        // ...
                    }
                });
    }


    private void Filechoose() {

        Intent filechoose = new Intent();
        filechoose.setType("image/'");
        filechoose.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(filechoose, 1);


    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imguri = data.getData();
            img.setImageURI(imguri);


        }

    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListner = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            int id = menuItem.getItemId();

            if (id == R.id.home) {

                Intent Home = new Intent(Profile.this, Home_Page.class);
                startActivity(Home);
                finish();
            } else if (id == R.id.car) {
                Intent CAR = new Intent(Profile.this, Car.class);
                startActivity(CAR);
                finish();
            } else if (id == R.id.Profie) {
                Intent Profile = new Intent(Profile.this, Profile.class);
                startActivity(Profile);
                finish();
            }
            return false;
        }
    };

    public void LOGOUT(android.view.View view) {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(Profile.this, Login.class));
        finish();
    }
}
