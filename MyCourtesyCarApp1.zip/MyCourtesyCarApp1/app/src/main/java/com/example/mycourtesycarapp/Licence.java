package com.example.mycourtesycarapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.io.File;
import java.io.IOException;
import java.net.DatagramSocket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Licence extends AppCompatActivity {


     private static Bitmap userImage1,userImage2;
    public static final String TAG = "TAG";
    Spinner mType;
    TextView mLicence;
    ImageView Front1,Back1;
    EditText mDriverName,mNumber,mDate;
    FirebaseAuth fAuth;
    FirebaseFirestore mStore;
    String Userid;
    Button Front, Back,Submit;
    DatePickerDialog.OnDateSetListener mDatePicker;

    String name[] = {"Learner's Licence    ","Restricted Licence    ","Full Licence    "};
    ArrayAdapter <String> adapter;
    String record="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_licence);



        mDriverName=findViewById(R.id.Name);
        mNumber=findViewById(R.id.Number);
        mType=findViewById(R.id.Spinner);
        mLicence=findViewById(R.id.LicenceT);
        mDate=findViewById(R.id.Date);
        mStore= FirebaseFirestore.getInstance();
        fAuth=FirebaseAuth.getInstance();
        Submit=findViewById(R.id.Create);
        Front=findViewById(R.id.Front);
        Front1=findViewById(R.id.cam);
        Back=findViewById(R.id.Back);
        Back1=findViewById(R.id.cam1);


        Front.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(i, 1);
            }
        });
        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ii = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(ii, 2);
            }
        });


        adapter= new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,name);
        BottomNavigationView bottomNavigationView = findViewById(R.id.menu);
        bottomNavigationView.setOnNavigationItemSelectedListener(navListner);









        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dexter.withActivity(Licence.this)

                        .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                        .withListener(new PermissionListener() {
                            @Override
                            public void
                            onPermissionGranted(PermissionGrantedResponse response) {
                                startActivity(new Intent(Licence.this, Home_Page.class));
                                finish();
                            }

                            @Override
                            public void
                            onPermissionDenied(PermissionDeniedResponse response) {
                                if (response.isPermanentlyDenied()){
                                    AlertDialog.Builder builder = new
                                            AlertDialog.Builder(Licence.this);
                                    builder.setTitle("Permission denied")
                                            .setMessage("Permission to Access Device  Location  is Permanently Denied. You will need to go Phone's setting and allow the Permission.")
                                            .setNegativeButton("Cancel", null)
                                            .setPositiveButton("OK",
                                                    new DialogInterface.OnClickListener() {
                                                        @Override
                                                        public void
                                                        onClick(DialogInterface dialog, int which) {
                                                            Intent intent =
                                                                    new Intent();
                                                            intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                                            intent.setData(Uri.fromParts("Package",getPackageName(),null));
                                                        }
                                                    })
                                            .show();
                                } else {
                                    Toast.makeText(Licence.this,"Permission denied", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void
                            onPermissionRationaleShouldBeShown(PermissionRequest permission,
                                                               PermissionToken token) {
                                token.continuePermissionRequest();
                            }
                        })
                        .check();

            }
        });

     mDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar Cal= Calendar.getInstance();
                int Year=Cal.get(Calendar.YEAR);
                int Month=Cal.get(Calendar.MONTH);
                int Day=Cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog Dialog= new DatePickerDialog(Licence.this,android.R.style.Theme_Holo_Light_Dialog_MinWidth,mDatePicker,Year,Month,Day);
                Dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                Dialog.show();
            }
        });
        mDatePicker = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG, "onDateSet: dd/mm/yyy: " + day + "/" + month + "/" + year);

                String date = day + "/" + month + "/" + year;
                mDate.setText(date);
            }
        };


        mType.setAdapter(adapter);
        mType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    switch (position)
                    {
                        case 0:
                            record = "Learner's Licence";
                            mLicence.setText(name[position]);
                            break;

                        case 1:
                            record="Restricted Licence";
                            mLicence.setText(name[position]);
                            break;

                        case 2:
                            record="Full Licence";
                            mLicence.setText(name[position]);
                            break;
                    }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

//  Camera Activity

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch(requestCode) {
            case 1:
                if (resultCode == RESULT_OK) {
                    userImage1 = (Bitmap) data.getExtras().get("data");
                    Bundle extras = data.getExtras();
                    userImage1 = (Bitmap) extras.get("data");
                    Front1.setImageBitmap(userImage1);
                }//if resultCode Case 1
                break;
            case 2:
                if (resultCode == RESULT_OK) {
                    userImage2 = (Bitmap) data.getExtras().get("data");
                    Bundle extras = data.getExtras();
                    userImage2 = (Bitmap) extras.get("data");
                    Back1.setImageBitmap(userImage2);
                }
        }


    }
    public  void  Create (View view){
         String DriverName = mDriverName.getText().toString().trim();
        String Number = mNumber.getText().toString().trim();
        String Type = mType.getSelectedItem().toString().trim();
        String Date = mDate.getText().toString().trim();

        Userid=fAuth.getCurrentUser().getUid();
        DocumentReference documentReference= mStore.collection("User").document(Userid);

        documentReference.update("Driver's Name",DriverName);
        documentReference.update("Licence Number",Number);
        documentReference.update("Licence Type",Type);
        documentReference.update("Date",Date);

    }


    private BottomNavigationView.OnNavigationItemSelectedListener navListner = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            int id = menuItem.getItemId();

            if (id == R.id.home) {

                Intent Home = new Intent(Licence.this, Home_Page.class);
                startActivity(Home);
                finish();
            } else if (id == R.id.car) {
                Intent CAR = new Intent(Licence.this, Car.class);
                startActivity(CAR);
                finish();
            } else if (id == R.id.Profie) {
                Intent Profile = new Intent(Licence.this, Profile.class);
                startActivity(Profile);
                finish();
            }
            return false;
        }
    };
}

