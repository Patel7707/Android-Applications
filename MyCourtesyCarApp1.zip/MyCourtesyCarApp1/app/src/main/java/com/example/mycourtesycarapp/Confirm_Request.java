package com.example.mycourtesycarapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.android.volley.Request.*;

public class Confirm_Request extends AppCompatActivity {

    EditText mPickup,mDropoff,mTime1,mTime2;
    Dialog mDialog;
    String UserID;
    FirebaseAuth mAuth;
    FirebaseFirestore mStore;
    Button Submit;
    ImageView mCar;
    TextView locationtext,CarName,CarYear;
    Double latitude = 0.0;
    Double longitude = 0.0;
    Geocoder geocoder;
    int i;

    // List<Address> addresses ;

    Location gps_loc = null, network_loc = null, final_loc =null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm__request);


        i=getIntent().getExtras().getInt("carValues");





        mDialog=new Dialog(this);
        BottomNavigationView bottomNavigationView=findViewById(R.id.menu);
        bottomNavigationView.setOnNavigationItemSelectedListener(navListner);
        mPickup=findViewById(R.id.PUDD);
        mDropoff=findViewById(R.id.DODD);
        mTime1=findViewById(R.id.PUDT);
        mTime2=findViewById(R.id.DODT);
        Submit=findViewById(R.id.Submit);
        CarName=findViewById(R.id.CarName);
        CarYear=findViewById(R.id.CarYear);
        mCar=findViewById(R.id.img1);

        mAuth= FirebaseAuth.getInstance();
        mStore= FirebaseFirestore.getInstance();
        UserID=mAuth.getCurrentUser().getEmail();


        if(i==1){
                mCar.setImageResource(R.drawable.mazda);
        }
        else if(i==2){
            mCar.setImageResource(R.drawable.mitsubishi1);
        }
        else if(i==3){
            mCar.setImageResource(R.drawable.nissan_gtr);
        }
        else if(i==4){
            mCar.setImageResource(R.drawable.ranger);
        }
        else if(i==5){
            mCar.setImageResource(R.drawable.seltos);
        }
        else if(i==6){
            mCar.setImageResource(R.drawable.corolla);
        }





        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                RequestQueue requestQueue = Volley.newRequestQueue(Confirm_Request.this);

                StringRequest stringRequest = new StringRequest(Method.POST, "https://thinkonictechnology.com/mail_api/sendmail.php", new Response.Listener<String>() {
                    @Override    public void onResponse(String response) {


                        Toast.makeText(Confirm_Request.this, "Sent..", Toast.LENGTH_SHORT).show();



                    }
                }, new Response.ErrorListener() {
                    @Override    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(Confirm_Request.this, "Error", Toast.LENGTH_SHORT).show();
                        Log.e("VOLLEY", error.getMessage());

                    }
                }) {
                    @Override    protected Map<String, String> getParams()  {

                        String mPick=mPickup.getText().toString();
                        String mDrop=mDropoff.getText().toString();
                        String mTimeup=mTime1.getText().toString();
                        String mTimeoff=mTime2.getText().toString();
                        String mName=CarName.getText().toString();
                        String mYear=CarYear.getText().toString();
                        String mLocation= locationtext.getText().toString();

                        Map<String, String> params = new HashMap<>();

                        params.put("mail",UserID);
                        params.put("msg","\nCar Name:"+mName+
                                         "\nCar Year:"+mYear+
                                         "\nPick Up Date:"+mPick+
                                         "\nDrop off Date:"+mDrop+
                                         "\nPick Up Time:"+mTimeup+
                                         "\nDrop off Time:"+mTimeoff+
                                         "Pickup Location:"+mLocation);
                        params.put("sub", "Details");


                        return params;
                    }


                };
                requestQueue.add(stringRequest);
            }
        });




        mPickup.setText(getIntent().getStringExtra("Data"));
        mDropoff.setText(getIntent().getStringExtra("Data1"));
        mTime1.setText(getIntent().getStringExtra("Time"));
        mTime2.setText(getIntent().getStringExtra("Time1"));
        CarName.setText(getIntent().getStringExtra("Name"));
        CarYear.setText(getIntent().getStringExtra("Year"));


        locationtext = (TextView) findViewById(R.id.Location);
        geocoder = new Geocoder(this, Locale.getDefault());


        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_NETWORK_STATE) != PackageManager.PERMISSION_GRANTED){

            Toast.makeText(this, "not granted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Granted", Toast.LENGTH_SHORT).show();
        }

        try {
            gps_loc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            network_loc = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        } catch (Exception e ){
            e.printStackTrace();
        }

        if (gps_loc != null){
            final_loc = gps_loc;
            latitude = final_loc.getLatitude();
            longitude = final_loc.getLongitude();

        } else if (network_loc != null){
            final_loc = network_loc;
            latitude = final_loc.getLatitude();
            longitude = final_loc.getLongitude();

        }
        else {
            latitude=0.0;
            longitude=0.0;
        }



        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address>
                    addresses = geocoder.getFromLocation(latitude, longitude, 1);
            if (addresses !=null && addresses.size()>0) {
                String address = addresses.get(0).getAddressLine(0);
                String area = addresses.get(0).getLocality();
                String city = addresses.get(0).getAdminArea();
                String postalcode = addresses.get(0).getPostalCode();
                String fulladress = address + ", " + area + ", " + city + ", " + postalcode;
                locationtext.setText(fulladress);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
    public void Showup1(View view){
        TextView Close;
        mDialog.setContentView(R.layout.custompopup);
        Close=mDialog.findViewById(R.id.Close);
        Close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        mDialog.show();
    }
    private  BottomNavigationView.OnNavigationItemSelectedListener navListner = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            int id= menuItem.getItemId();

            if (id == R.id.home)
            {

                Intent Home = new Intent(Confirm_Request.this,Home_Page.class);
                startActivity(Home);
                finish();
            }
            else if (id == R.id.car)
            {
                Intent  CAR = new Intent(Confirm_Request.this,Car.class);
                startActivity(CAR);
                finish();
            }
            else if (id == R.id.Profie)
            {
                Intent  Profile = new Intent(Confirm_Request.this,Profile.class);
                startActivity(Profile);
                finish();
            }
            return false;
        }

    };


}
