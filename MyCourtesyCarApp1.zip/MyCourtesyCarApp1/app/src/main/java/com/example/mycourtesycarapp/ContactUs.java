package com.example.mycourtesycarapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class ContactUs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);

        BottomNavigationView bottomNavigationView=findViewById(R.id.menu);
        bottomNavigationView.setOnNavigationItemSelectedListener(navListner);
    }
    private  BottomNavigationView.OnNavigationItemSelectedListener navListner = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            int id= menuItem.getItemId();

            if (id == R.id.home)
            {

                Intent Home = new Intent(ContactUs.this,Home_Page.class);
                startActivity(Home);
                finish();
            }
            else if (id == R.id.car)
            {
                Intent  CAR = new Intent(ContactUs.this,Car.class);
                startActivity(CAR);
                finish();
            }
            else if (id == R.id.Profie)
            {
                Intent  Profile = new Intent(ContactUs.this,Profile.class);
                startActivity(Profile);
                finish();
            }
            return false;
        }

    };
}
