package com.example.preconceptionapp.Util;

public class Constants {
    public static final String registerUrl = "http://192.168.0.9/preconception/register.php";
    public static final String loginUrl = "http://192.168.0.9/preconception/login.php";

}
